# ROR Architecture

## Data flow
Animal → audio/video/sensor → preprocessing → signal events → multimodal features → pattern/context analysis → evidence-scoped hypothesis → human response → experimental signal → response monitoring → research log → dataset.

## AI boundaries
Audio pipeline: WAV/PCM → optional noise reduction → segmentation → spectrogram → acoustic features → embedding → clustering/classification.
Video pipeline: frames → animal detection → pose/body movement → behavior features.
Multimodal model: acoustic embedding + visual embedding + context → pattern model.

The MVP ships a deterministic acoustic feature extractor and demo similarity grouping. Model adapters should be introduced behind interfaces so replacing the demo implementation does not change the API contract.

## Research protocol
- Pre-register hypotheses when practical.
- Preserve raw inputs and preprocessing metadata.
- Separate observation from interpretation.
- Require repeated observations across individuals/environments before confidence increases.
- Keep positive, negative and uncertain examples.
- Never train directly from one human interpretation.
- Treat generated playback as an experiment, not a translation.
- Record unsuccessful/no-response trials.
