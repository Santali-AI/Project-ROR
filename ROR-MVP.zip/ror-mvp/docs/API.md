# API routes

- `GET /health`
- `GET /api/species`
- `POST /api/observations`
- `GET /api/observations/{id}`
- `POST /api/audio/analyze?observation_id={id}` — multipart audio
- `GET /api/signals/{id}`
- `POST /api/interpretations`
- `POST /api/response/generate`
- `POST /api/experiments`
- `GET /api/research/statistics`

The response generator intentionally returns conservative experimental parameters and does not map human phrases to a claimed animal-language equivalent.
