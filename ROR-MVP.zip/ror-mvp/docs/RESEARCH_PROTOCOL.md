# Research-safe interpretation protocol

1. `OBSERVED`: directly measurable event, e.g. “low-frequency signal occurred and two nearby animals vocalized within 4 seconds.”
2. `LIKELY`: repeated evidence supports a pattern, but semantics remain unverified.
3. `POSSIBLE`: plausible hypothesis with limited or mixed evidence.
4. `UNKNOWN`: insufficient evidence for a useful interpretation.

Confidence measures evidence consistency, not certainty that the hypothesis means a particular human phrase.

For playback, use species-specific welfare limits, conservative levels, short trials, control trials, and researcher approval. Never infer consent or emotional state solely from one response.
