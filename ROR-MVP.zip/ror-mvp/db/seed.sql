INSERT INTO animals (species,name,location,notes) VALUES
('elephant','Demo Elephant E-01','demo-reserve','Synthetic demonstration record; not field evidence.'),
('dog','Demo Dog D-01','demo-home','Synthetic demonstration record; not field evidence.'),
('birds','Demo Bird B-01','demo-woodland','Synthetic demonstration record; not field evidence.');
