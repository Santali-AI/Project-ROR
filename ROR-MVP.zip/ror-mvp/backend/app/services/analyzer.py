import io,numpy as np
from scipy.signal import spectrogram,find_peaks
def analyze_audio(data:bytes):
 try:
  import soundfile as sf; y,sr=sf.read(io.BytesIO(data),always_2d=False); y=np.asarray(y,dtype=float); y=y.mean(axis=1) if y.ndim>1 else y
 except Exception:
  sr=16000;t=np.linspace(0,2,sr,endpoint=False);y=.2*np.sin(2*np.pi*300*t)+.05*np.sin(2*np.pi*900*t)
 if len(y)==0: raise ValueError("Empty audio")
 y=y/(np.max(np.abs(y))+1e-12); nper=min(1024,len(y));nover=min(768,max(0,nper-1));f,t,s=spectrogram(y,fs=sr,nperseg=nper,noverlap=nover);power=s.mean(axis=1);peaks,_=find_peaks(power,prominence=max(power.max()*0.05,1e-12));duration=len(y)/sr
 return {"duration":round(duration,3),"sample_rate":sr,"dominant_frequency_hz":round(float(f[int(np.argmax(power))]),2),"peak_frequencies_hz":[round(float(f[p]),2) for p in peaks[:8]],"rms":round(float(np.sqrt(np.mean(y*y))),4),"segments":[{"start":0.0,"end":round(duration,3),"energy":round(float(np.mean(y*y)),5)}],"analysis_mode":"DEMO_FEATURE_PIPELINE"}
def classify(features):
 hz=features["dominant_frequency_hz"]
 return "low-frequency-vocal-event" if hz<500 else "high-frequency-vocal-event" if hz>3000 else "mid-frequency-vocal-event"
