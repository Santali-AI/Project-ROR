from fastapi import APIRouter
from sqlalchemy.orm import Session
from ..main import engine
from ..models import Interpretation
from ..schemas import InterpretationIn
router=APIRouter(tags=['interpretations'])
@router.post('/interpretations')
def create(p:InterpretationIn):
 with Session(engine) as db:
  x=Interpretation(**p.model_dump());db.add(x);db.commit();db.refresh(x);return {'id':x.id,'signal_id':x.signal_id,'hypothesis':x.hypothesis,'evidence_count':x.evidence_count,'confidence':x.confidence,'status':x.status,'research_safe_status':x.status,'note':'Hypothesis, not verified translation.'}
