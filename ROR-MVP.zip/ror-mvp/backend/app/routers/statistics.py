from fastapi import APIRouter
from sqlalchemy import func
from sqlalchemy.orm import Session
from ..main import engine
from ..models import Observation,Signal,Interpretation,Experiment
router=APIRouter(tags=['research'])
@router.get('/research/statistics')
def stats():
 with Session(engine) as db:return {'observations':db.query(func.count(Observation.id)).scalar(),'signals':db.query(func.count(Signal.id)).scalar(),'interpretations':db.query(func.count(Interpretation.id)).scalar(),'experiments':db.query(func.count(Experiment.id)).scalar(),'evidence_policy':'No interpretation is a verified translation unless independently established.'}
