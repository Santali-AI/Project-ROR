from fastapi import APIRouter,HTTPException
from sqlalchemy.orm import Session
from ..main import engine
from ..models import Signal
router=APIRouter(tags=['signals'])
@router.get('/signals/{sid}')
def get(sid:str):
 with Session(engine) as db:
  s=db.get(Signal,sid)
  if not s: raise HTTPException(404,'Signal not found')
  return {'id':s.id,'observation_id':s.observation_id,'frequency_features':s.frequency_features,'duration':s.duration,'repetition':s.repetition,'classification':s.classification,'confidence':s.confidence}
