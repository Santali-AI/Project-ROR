from fastapi import APIRouter, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from ..main import engine
from ..models import Signal, Observation
from ..services.analyzer import analyze_audio, classify
router=APIRouter(tags=['audio'])
@router.post('/audio/analyze')
async def analyze(observation_id:str,file:UploadFile=File(...)):
 if not file.content_type or not file.content_type.startswith('audio/'): raise HTTPException(400,'Upload an audio file')
 data=await file.read()
 try: features=analyze_audio(data)
 except Exception as e: raise HTTPException(422,str(e))
 with Session(engine) as db:
  obs=db.get(Observation,observation_id)
  if not obs: raise HTTPException(404,'Observation not found')
  sig=Signal(observation_id=observation_id,frequency_features=features,duration=features['duration'],classification=classify(features),confidence=.35)
  db.add(sig);db.commit();db.refresh(sig);obs.detected_signals=(obs.detected_signals or [])+[sig.id];db.commit()
  return {'signal_id':sig.id,'features':features,'classification':sig.classification,'confidence':.35,'status':'POSSIBLE'}
