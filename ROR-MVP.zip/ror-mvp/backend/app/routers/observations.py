from fastapi import APIRouter,HTTPException
from sqlalchemy.orm import Session
from ..models import Observation
from ..schemas import ObservationIn
from ..main import engine
router=APIRouter(tags=['observations'])
@router.post('/observations')
def create(p:ObservationIn):
 with Session(engine) as db:
  o=Observation(species=p.species,animal_id=p.animal_id,audio_url=p.audio_url,video_url=p.video_url,environmental_context=p.environmental_context,behaviour=p.behaviour);db.add(o);db.commit();db.refresh(o);return {'id':o.id,'species':p.species,'status':'created'}
@router.get('/observations/{oid}')
def get(oid:str):
 with Session(engine) as db:
  o=db.get(Observation,oid)
  if not o: raise HTTPException(404,'Observation not found')
  return {'id':o.id,'animal_id':o.animal_id,'timestamp':o.timestamp,'environmental_context':o.environmental_context,'behaviour':o.behaviour,'detected_signals':o.detected_signals}
