from fastapi import APIRouter
from sqlalchemy.orm import Session
from ..main import engine
from ..models import Experiment
from ..schemas import ExperimentIn
router=APIRouter(tags=['experiments'])
@router.post('/experiments')
def create(p:ExperimentIn):
 with Session(engine) as db:
  x=Experiment(**p.model_dump());db.add(x);db.commit();db.refresh(x);return {'id':x.id,'status':'logged','result':x.result,'experimental':True}
