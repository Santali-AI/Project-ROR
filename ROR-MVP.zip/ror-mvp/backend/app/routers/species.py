from fastapi import APIRouter
router=APIRouter(tags=['species'])
@router.get('/species')
def species(): return [{'id':x,'name':x.title(),'status':'MVP'} for x in ['cow','cat','dog','birds','elephant']]
