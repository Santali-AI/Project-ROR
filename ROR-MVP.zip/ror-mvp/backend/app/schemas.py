from pydantic import BaseModel,Field
from typing import Any,Literal
class ObservationIn(BaseModel): animal_id:str|None=None; species:str; timestamp:str|None=None; audio_url:str|None=None; video_url:str|None=None; environmental_context:dict[str,Any]={}; behaviour:dict[str,Any]={}
class InterpretationIn(BaseModel): signal_id:str; hypothesis:str; evidence_count:int=0; confidence:float=Field(0,ge=0,le=1); status:Literal["OBSERVED","LIKELY","POSSIBLE","UNKNOWN"]="UNKNOWN"
class ExperimentIn(BaseModel): interpretation_id:str|None=None; human_message:str=Field(min_length=1,max_length=1000); generated_signal:dict[str,Any]; playback_metadata:dict[str,Any]={}; animal_response:dict[str,Any]={}; result:str="UNRESOLVED"; researcher_notes:str|None=None
