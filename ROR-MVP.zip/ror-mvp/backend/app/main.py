import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from .models import Base
from .routers import species, observations, audio, interpretations, experiments, signals, statistics, response
engine=create_engine(os.getenv("DATABASE_URL","sqlite:///./ror.db"),pool_pre_ping=True)
@asynccontextmanager
async def lifespan(app): Base.metadata.create_all(engine); yield
app=FastAPI(title="ROR Research API",version="0.1.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=os.getenv("CORS_ORIGINS","http://localhost:3000").split(","),allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for r in [species.router,observations.router,audio.router,interpretations.router,experiments.router,signals.router,statistics.router,response.router]: app.include_router(r,prefix="/api")
@app.get("/health")
def health(): return {"status":"ok","research_mode":"evidence_scoped"}
