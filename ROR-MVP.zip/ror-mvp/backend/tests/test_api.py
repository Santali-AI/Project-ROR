import os
os.environ['DATABASE_URL']='sqlite:///./test_ror.db'
from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_health(): assert client.get('/health').status_code==200
def test_species(): assert len(client.get('/api/species').json())==5
def test_observation():
 r=client.post('/api/observations',json={'species':'elephant','environmental_context':{'location':'demo'}});assert r.status_code==200
